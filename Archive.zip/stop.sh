#!/bin/bash

# PO Manager - Durdurma Scripti

echo "🛑 PO Manager durduruluyor..."

# Renk kodları
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# PID dosyalarını kontrol et
DJANGO_PID_FILE="/tmp/po_manager_django.pid"
VUE_PID_FILE="/tmp/po_manager_vue.pid"

# Django'yu durdur
if [ -f "$DJANGO_PID_FILE" ]; then
    DJANGO_PID=$(cat "$DJANGO_PID_FILE")
    if ps -p $DJANGO_PID > /dev/null 2>&1; then
        kill $DJANGO_PID
        echo -e "${GREEN}✓ Django Backend durduruldu (PID: $DJANGO_PID)${NC}"
    fi
    rm "$DJANGO_PID_FILE"
else
    # PID dosyası yoksa process'i isimle bul ve durdur
    pkill -f "python manage.py runserver" && echo -e "${GREEN}✓ Django Backend durduruldu${NC}"
fi

# Vue'yu durdur
if [ -f "$VUE_PID_FILE" ]; then
    VUE_PID=$(cat "$VUE_PID_FILE")
    if ps -p $VUE_PID > /dev/null 2>&1; then
        kill $VUE_PID
        echo -e "${GREEN}✓ Vue Frontend durduruldu (PID: $VUE_PID)${NC}"
    fi
    rm "$VUE_PID_FILE"
else
    # PID dosyası yoksa process'i isimle bul ve durdur
    pkill -f "vite" && echo -e "${GREEN}✓ Vue Frontend durduruldu${NC}"
fi

# Log dosyalarını temizle (opsiyonel)
# rm -f /tmp/django.log /tmp/vue.log

echo ""
echo -e "${GREEN}✅ PO Manager durduruldu!${NC}"
