#!/bin/bash

# PO Manager - Durum Kontrolü

echo "📊 PO Manager Durum Kontrolü"
echo ""

# Renk kodları
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Django kontrolü
if pgrep -f "python manage.py runserver" > /dev/null; then
    DJANGO_PID=$(pgrep -f "python manage.py runserver")
    echo -e "${GREEN}✓ Django Backend çalışıyor${NC} (PID: $DJANGO_PID)"
    echo -e "  ${BLUE}http://127.0.0.1:8000${NC}"
    
    # Port dinleme kontrolü
    if netstat -tuln 2>/dev/null | grep -q ":8000 "; then
        echo -e "  Port 8000: ${GREEN}Aktif${NC}"
    else
        echo -e "  Port 8000: ${YELLOW}Bekleniyor...${NC}"
    fi
else
    echo -e "${RED}✗ Django Backend çalışmıyor${NC}"
fi

echo ""

# Vue kontrolü
if pgrep -f "vite" > /dev/null; then
    VUE_PID=$(pgrep -f "vite")
    echo -e "${GREEN}✓ Vue Frontend çalışıyor${NC} (PID: $VUE_PID)"
    
    # Hangi portta çalıştığını bul
    if netstat -tuln 2>/dev/null | grep -q ":5173 "; then
        echo -e "  ${BLUE}http://localhost:5173${NC}"
        echo -e "  Port 5173: ${GREEN}Aktif${NC}"
    elif netstat -tuln 2>/dev/null | grep -q ":5174 "; then
        echo -e "  ${BLUE}http://localhost:5174${NC}"
        echo -e "  Port 5174: ${GREEN}Aktif${NC}"
    else
        echo -e "  Port: ${YELLOW}Tespit edilemiyor${NC}"
    fi
else
    echo -e "${RED}✗ Vue Frontend çalışmıyor${NC}"
fi

echo ""
echo -e "${BLUE}═══════════════════════════════════════${NC}"

# Database kontrolü
BACKEND_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )/po_manager"
if [ -f "$BACKEND_DIR/db.sqlite3" ]; then
    DB_SIZE=$(du -h "$BACKEND_DIR/db.sqlite3" | cut -f1)
    echo -e "Database: ${GREEN}$DB_SIZE${NC}"
else
    echo -e "Database: ${RED}Bulunamadı${NC}"
fi

# Log dosyaları
if [ -f "/tmp/django.log" ]; then
    DJANGO_LOG_SIZE=$(du -h /tmp/django.log | cut -f1)
    echo -e "Django Log: ${GREEN}$DJANGO_LOG_SIZE${NC}"
fi

if [ -f "/tmp/vue.log" ]; then
    VUE_LOG_SIZE=$(du -h /tmp/vue.log | cut -f1)
    echo -e "Vue Log: ${GREEN}$VUE_LOG_SIZE${NC}"
fi

echo ""
